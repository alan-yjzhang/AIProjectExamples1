from .content_loss import ContentLoss
from .style_loss import StyleLoss
from .tv_loss import TotalVariationLoss